    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Registration Year:</strong>
                {!! Form::string('reg_year', null, array('placeholder' => 'Registration Year','class' => 'form-control')) !!}
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Registration Status:</strong>
                {!! Form::string('reg_status', null, array('placeholder' => 'Registration Status','class' => 'form-control')) !!}
            </div>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Organisation Name:</strong>
                {!! Form::string('org_name', null, array('placeholder' => 'Organisation Name','class' => 'form-control')) !!}
            </div>

            <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Organisation Type:</strong>
                {!! Form::string('org_type', null, array('placeholder' => 'Organisation Type','class' => 'form-control')) !!}
            </div>

            <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Email:</strong>
                {!! Form::email('email', null, array('placeholder' => 'Email','class' => 'form-control')) !!}
            </div>

            <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Phone:</strong>
                {!! Form::smallIntege('smallIntege', null, array('placeholder' => 'Phone','class' => 'form-control')) !!}
            </div>

            <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Amount:</strong>
                {!! Form::string('amount', null, array('placeholder' => 'Amount','class' => 'form-control')) !!}
            </div>
        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </div>