<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Member extends Model
{
        protected $fillable = [
        'reg_year', 'reg_status ', 'org_name', 'org_type', 'email', 'phonenumber ', 'phonenumber', 'amount'
    ];
}
